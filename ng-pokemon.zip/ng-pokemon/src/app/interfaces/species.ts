export interface Species {
  name: string;
  url: string;
}
