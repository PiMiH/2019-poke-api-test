export interface Pokemon {
}
