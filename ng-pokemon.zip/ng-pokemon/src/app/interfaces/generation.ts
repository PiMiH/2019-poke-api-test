export interface Generation {
  abilities: object[];
  id: number;
  main_region: object;
  moves: object[];
  name: string;
  names: object[];
  pokemon_species: object[];
  types: object[];
  version_groups: object[];
}